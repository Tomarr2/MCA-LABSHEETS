
import pandas as pd
from sklearn.datasets import load_diabetes

# Load the Diabetes regression dataset
diabetes = load_diabetes(as_frame=True)

# Convert the dataset into a Pandas DataFrame
df = diabetes.frame

# Display the dataset
print("Regression Dataset:")
print(df)
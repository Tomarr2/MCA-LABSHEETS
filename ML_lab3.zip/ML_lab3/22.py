from sklearn.datasets import load_diabetes
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

X, y = load_diabetes(return_X_y=True)

X = X[:, [2]]

poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X)

model = LinearRegression()
model.fit(X_poly, y)

value = float(input("Enter feature value: "))

new_value = [[value]]

new_value_poly = poly.transform(new_value)

prediction = model.predict(new_value_poly)

print("Predicted Target Value:", prediction[0])
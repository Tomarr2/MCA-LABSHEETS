from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

diabetes = load_diabetes(as_frame=True)
df = diabetes.frame

# Use BMI as single input
X = df[["bmi"]]
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

# Create model
model = LinearRegression()

print("Simple Linear Regression model created successfully.")
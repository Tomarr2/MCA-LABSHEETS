from sklearn.datasets import load_linnerud

# Load Linnerud dataset
X, y = load_linnerud(return_X_y=True)

print("Input Features:")
print(X)

print("\nTarget Values:")
print(y)

print("\nNumber of Input Features:", X.shape[1])
print("Number of Target Variables:", y.shape[1])
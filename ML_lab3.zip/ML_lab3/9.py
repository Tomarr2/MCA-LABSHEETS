import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

diabetes = load_diabetes(as_frame=True)
df = diabetes.frame

X = df[["bmi"]]
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

predictions = model.predict(X_test)

plt.scatter(X_test["bmi"], y_test, label="Actual Values")
plt.plot(X_test["bmi"], predictions, label="Regression Line")

plt.xlabel("BMI")
plt.ylabel("Target")
plt.title("Simple Linear Regression")
plt.legend()
plt.show()
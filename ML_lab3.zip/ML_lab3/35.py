import joblib

# Load saved model
model = joblib.load("linear_regression_model.pkl")

# User input
bmi = float(input("Enter BMI value: "))

# Prediction
prediction = model.predict([[bmi]])

print("Predicted Target Value:", prediction[0])
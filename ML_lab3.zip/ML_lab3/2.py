import pandas as pd
from sklearn.datasets import load_diabetes

diabetes = load_diabetes(as_frame=True)
df = diabetes.frame

print("First Five Records:")
print(df.head())

print("\nLast Five Records:")
print(df.tail())
from sklearn.datasets import load_diabetes
from sklearn.preprocessing import StandardScaler

# Load dataset
X, y = load_diabetes(return_X_y=True)

print("Before Scaling:")
print(X[:5])

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("\nAfter Scaling:")
print(X_scaled[:5])
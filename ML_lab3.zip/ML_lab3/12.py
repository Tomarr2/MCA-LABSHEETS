from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pandas as pd

diabetes = load_diabetes(as_frame=True)
df = diabetes.frame

X = df[["bmi"]]
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

# User input
bmi_value = float(input("Enter BMI value: "))

new_data = pd.DataFrame({
    "bmi": [bmi_value]
})

prediction = model.predict(new_data)

print("Predicted Target Value:", prediction[0])
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

X, y = load_diabetes(return_X_y=True)

X = X[:, [2]]

# Degree 2
poly2 = PolynomialFeatures(degree=2)
X2 = poly2.fit_transform(X)

model2 = LinearRegression()
model2.fit(X2, y)

# Degree 3
poly3 = PolynomialFeatures(degree=3)
X3 = poly3.fit_transform(X)

model3 = LinearRegression()
model3.fit(X3, y)

# Sorted values for smooth curve
x_values = np.linspace(X.min(), X.max(), 100).reshape(-1, 1)

y2 = model2.predict(poly2.transform(x_values))
y3 = model3.predict(poly3.transform(x_values))

plt.scatter(X, y)

plt.plot(x_values, y2, label="Degree 2")
plt.plot(x_values, y3, label="Degree 3")

plt.xlabel("Feature")
plt.ylabel("Target")
plt.title("Polynomial Regression Curves")
plt.legend()

plt.show()
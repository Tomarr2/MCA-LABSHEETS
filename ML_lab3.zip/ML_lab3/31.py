from sklearn.datasets import load_diabetes
from sklearn.preprocessing import StandardScaler

# Load features directly
X, y = load_diabetes(return_X_y=True)

# Standardization
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("Original Features:")
print(X[:5])

print("\nStandardized Features:")
print(X_scaled[:5])